<?php require_once('includes/initialize.php');  ?>

<?php

if($session->is_logged_in()) {	
	if(isset($_POST['change_privacy'])){
		$profile->Privacy = $database->escape_value($_POST['privacy_profile']);
		if($profile->update_profile()){
			redirect_to('index.php');
		} else {
			redirect_to('index.php');
		}
	}
	if(isset($_POST['privacy_eval'])){
		$profile->Privacy_eval = $database->escape_value($_POST['privacy_eval']);
		if($profile->update_profile()){
			redirect_to('evaluation.php');
		}
	}
}




?>