<?php require_once('includes/initialize.php');  ?>

<?php

if($session->is_logged_in()) {
    if(isset($_GET['album_id']))   {


      $album = new Album;
      $album->Album_ID = trim($_GET['album_id']);
      if($album->delete_album()){
          redirect_to('photos.php');
      }

    }

}




?>