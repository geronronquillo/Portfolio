<?php require_once('includes/initialize.php');  ?>

<?php

if($session->is_logged_in()) {
    if(isset($_GET['photo_id']) )  {

	  $photo = Photo::find_photo_by_id($_GET['photo_id']);
      if($photo->destroy()){
      redirect_to('picture.php?album_id=' . $_GET['album_id']);
      }

    }
 
}




?>