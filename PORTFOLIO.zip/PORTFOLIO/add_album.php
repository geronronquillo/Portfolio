<?php require_once('includes/initialize.php');  ?>

<?php 

if( $session->is_logged_in() && isset($_POST['submit_album'])){

	$album = new Album();
	$album->Title = $database->escape_value($_POST["title"]);
	$album->Album_name = $database->escape_value($_POST["Album_name"]);
	$album->Semester_ID = $database->escape_value($_POST["Semester_ID"]);

	if($album->create_album($album->Album_name, $album->Semester_ID)){
		$session->message("Album added Successfully !");
		redirect_to('photos.php');

	} else {
		$session->message("Failed to add new Album !");
		redirect_to('photos.php');

	}


}



?>