<?php require_once('includes/initialize.php');  ?>

<?php 

if( $session->is_logged_in() && isset($_POST['add_profile_photo'])){

    $data = file_get_contents($_FILES['photo']['tmp_name']);
   // $data = mysql_real_escape_string($data);
	$profile->Picture = $data;

	if($profile->update_profile()){	
		redirect_to("index.php");
	}


}



?>