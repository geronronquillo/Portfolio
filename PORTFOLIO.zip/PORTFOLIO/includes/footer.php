            <div class="container">
                <a href="http://www.monkey.com/" title="Proceed to Monkey Website"><img height="100" width="400" id="akan-logo" src="img/monkey2.png" ></a>
                <div class="text-muted" id="footer-left">
                    Profile Student<br>
                    This page is maintained by: MSU student,<br>
                    College of Information Technology,<br>
                    Mindanao State University,<br>
                    Marawi City
                    <br><br>
                    <b>All rights reserved © 2015 MSU Marawi Campus</b>
                    <br><span class="footer_creator">Developed by Geron Galela Ronquillo, Student, MSU-Marawi</span>                </div>
                <div class="text-muted " id="footer-right">
                    For MSU-Profile related comments and suggestions,
                    please email us at geronronquillo@gmail.com
                    <br><br>
                    <p><b>Follow us on:</b><br>
                        <a href="https://www.facebook.com/geronronquillo" title="Follow us on our Facebook page"><img src="img/facebook.png"></a>&nbsp;
                        <a href="login.php" title="Follow us on our Twitter account" name="twitter"><img src="img/twitter.png"></a>
                    </p>                        
                </div>
                <p style="clear:both;">&nbsp;</p>
            </div>