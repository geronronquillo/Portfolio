<?php

//require_once(LIB_PATH.DS."config.php");
require_once(LIB_PATH.DS."database.php");

class Subject extends DatabaseObject {

	protected static $table_name="subject"; 
	protected static $db_fields = array('Subject_ID', 'Subject_name', 'Description', 'Unit', 
											'Grade', 'Instructor_name', 'Section', 
											'Room', 'Profile_ID', 'Semester_ID', 'Complete_grade' ); 
	public $Subject_ID ; 
	public $Subject_name ;
	public $Description ;
	public $Unit ;
	public $Grade ;
	public $Instructor_name ;
	public $Section ;
	public $Room ;
	public $Profile_ID ;
	public $Semester_ID ;
	public $Complete_grade;

	function __construct() {
		
	}

	public static function get_all_subjects(){
		global $database;
		
		$sql = "SELECT * FROM subject ";
		$sql .= "WHERE Profile_ID=" . $database->escape_value($_SESSION['profile_id']);
		$subject = Subject::find_by_sql($sql);

		return $subject;
	}


	public function delete() {
		global $database;
		$sql = "DELETE FROM subject ";
		$sql .= " WHERE Subject_ID='" . $database->escape_value($this->Subject_ID) . "' ";
		$sql .= "LIMIT 1";
		$database->query($sql);
		return ($database->affected_rows() == 1) ? true : false ;
	} 	

	public static function get_subject_by_id($subj_id = 0){
		global $database;
		
		$sql = "SELECT * FROM subject ";
		$sql .= "WHERE Subject_ID=" . $database->escape_value($subj_id);
		$sql .= " LIMIT 1 ";
		$subject = Subject::find_by_sql($sql);

		return array_shift($subject);
	}

	/*
 	public function find_by_sem_id($sem_id){
		$sql = "SELECT * FROM subject ";
		$sql .= "WHERE Semester_ID=" . $database->escape_value($sem_id);
		$subject = Subject::find_by_sql($sql); 		
		return $subject;
 	}
 	*/

  	//common database methods

}

if(isset($_SESSION['profile_id'])){ 
	// $sql = "SELECT * FROM subject ";
	// $sql .= "WHERE Profile_ID=" . $database->escape_value($_SESSION['profile_id']);
	// $subject = Subject::find_by_sql($sql);
	$subject = Subject::get_all_subjects();
}

?>  