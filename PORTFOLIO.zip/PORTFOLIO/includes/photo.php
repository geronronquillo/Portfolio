<?php

//require_once(LIB_PATH.DS."config.php");
require_once(LIB_PATH.DS."database.php");

class Photo extends DatabaseObject {

	protected static $table_name="photo";
	protected static $db_fields = array( "Photo_ID", "Photo_name", 	"Album_ID", 	"status", 	"File_name", "Date_added" );
	 public $Photo_ID;
	 public $Photo_name; 	
	 public $Album_ID; 	
	 public $status;
	 public $File_name;
	 public $Date_added;
	

	
	private $temp_path;
	protected $upload_dir="photos";
	public $errors = array();
	
	function __construct() {
		
	}

 	protected $upload_errors = array(
			UPLOAD_ERR_OK			=> "No errors.",
			UPLOAD_ERR_INI_SIZE  	=> "Larger than upload_max_filesize.",
		  	UPLOAD_ERR_FORM_SIZE 	=> "Larger than form MAX_FILE_SIZE.",
		  	UPLOAD_ERR_PARTIAL 		=> "Partial upload.",
		  	UPLOAD_ERR_NO_FILE 		=> "No file.",
		  	UPLOAD_ERR_NO_TMP_DIR 	=> "No temporary directory.",
		  	UPLOAD_ERR_CANT_WRITE 	=> "Can't write to disk.",
		  	UPLOAD_ERR_EXTENSION 	=> "File upload stopped by extension."
	);

	public function attach_file($file) {
		
		if(!$file || empty($file) || !is_array($file)) {
			$this->error[] = "No file was uploaded";
			return false;

		} elseif($file['error'] != 0) {
			$this->error[] = $this->upload_errors[$file['error']];
			return false; 
		} else {
			$this->temp_path	= $file['tmp_name'];
			$this->File_name	= date('s') . md5(basename($file['name'])) . $file['name'] ;
			//$this->type			= $file['type'];
			//$this->size			= $file['size'];
			return true;
		}
	}

	//this method was overwritten frm the parent class. Because of error differences
	public function save() { 
		if(!empty($this->errors)) { 
			return false; 
		}


		if(empty($this->File_name) || empty($this->temp_path)) {
			$this->errors[] = "The file location was not available." . $this->File_name . $this->temp_path . "--" ;
			return false;
		}
		
		$target_path = SITE_ROOT.DS.$this->upload_dir.DS.$this->File_name; 
		if(file_exists($target_path)) {
			$this->errors[] = "The file {$this->File_name} already exists.";
			return false;
		}

		if(move_uploaded_file($this->temp_path, $target_path)) {
			// Successs
			if($this->create()) {
				unset($this->temp_path);
				return true;
			}
		} else {
			$this->erros[] = "The file upload failed, possibly due to incorrect permissions on the upload folder.";
			return false;
		}

		
	}

	public function pdf_path() {
		return $this->upload_dir.'/'.$this->File_name;
	}

	public function size_as_text() {
		if($this->size < 1024) {
			return "{$this->size} bytes";
		} elseif($this->size < 1048576) {
			$size_kb = round($this->size / 1024);
			return "{$size_kb} KB";
		} else {
			$size_mb = round($this->size / 1048576, 1);
			return "{$size_mb} MB";
		}
	}



	public function date_format(){
		return date_format(date_create($this->date_posted) ,"F d, Y. D");
	}	
	public function public_date_format(){
		return date_format(date_create($this->date_posted) ,"F d, Y");
	}

	public function destroy() {
		if($this->delete_photo()) {
			$target_path = SITE_ROOT.DS.'photos'.DS.$this->File_name;
			return unlink($target_path) ? true : false;		
		} else {
			
		}
	}
  
	public static function get_by_album_id($Album_ID){
		global $database;
		$sql = "SELECT * FROM photo ";
		$sql .= " WHERE Album_ID=" . $database->escape_value($Album_ID);
		$photos = Photo::find_by_sql($sql);
		return $photos;
	}
 

}


?>  