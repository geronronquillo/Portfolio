<?php
				
    $dbhost = "localhost";
    $dbuser = "root";
    $dbpass = "";
    $dbname = "portfolio";
    
    $conn = mysql_connect($dbhost, $dbuser, $dbpass);
    mysql_select_db($dbname) or die(mysql_error());

    if($_POST['action'] == "addAlbum") {
        echo addAlbum($_POST['albumName'], $_POST['activityID']);
    }
	
	if($_POST['action'] == "addPhoto") {
        echo addPhoto($_POST['fileName'], $_POST['isCover'], $_POST['data'], $_POST['date'], $_POST['albumID']);
    }
    
    function addAlbum($albumName, $activityID){
        
        $dbhost = "localhost";
        $dbuser = "root";
        $dbpass = "";
        $dbname = "portfolio";
        
        $conn = mysql_connect($dbhost, $dbuser, $dbpass);
        mysql_select_db($dbname) or die(mysql_error());
        $command = 'INSERT INTO album (Album_name, Activity_ID) VALUES ("'.$albumName.'", '.$activityID.')';
        $callback = mysql_query( $command, $conn );
        if (! $callback ) {
            return ('Could not create album: ' . mysql_error());
        } else {
            return "success";    
        }
    }
	
	function addPhoto($fileName, $isCover, $data, $date, $albumID){
		$dbhost = "localhost";
        $dbuser = "root";
        $dbpass = "";
        $dbname = "portfolio";
        
        $conn = mysql_connect($dbhost, $dbuser, $dbpass);
        mysql_select_db($dbname) or die(mysql_error());
        $command = 'INSERT INTO photo (Date_added, filename, IsAlbumCover, photoData, Album_ID, Photo_name, status) '.
				   'VALUES ("'.$date.'", "'.$fileName.'", '.$isCover.', "'.$data.'", '.$albumID.', "'.$fileName.'", "private")';
				   
        $callback = mysql_query( $command, $conn );
        if (! $callback ) {
            return ('Could not create album: ' . mysql_error());
        } else {
            return "success";    
        }
    }
	
	
?>