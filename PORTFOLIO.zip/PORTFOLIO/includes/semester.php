<?php

//require_once(LIB_PATH.DS."config.php");
require_once(LIB_PATH.DS."database.php");

class Semester extends DatabaseObject {

	protected static $table_name="semester"; 
	protected static $db_fields = array('Semester_ID', 'Profile_ID' , 'School_year', 'Semester_period'); 
	
	public $Semester_ID ; 
	public $Profile_ID ;
	public $School_year ;
	public $Semester_period ;


	function __construct() {
		
	}


	
	public function delete() {
		global $database;
		$sql = "DELETE FROM semester ";
		$sql .= " WHERE Semester_ID='" . $database->escape_value($this->Semester_ID) . "' ";
		$sql .= "LIMIT 1";
		$database->query($sql);
		return ($database->affected_rows() == 1) ? true : false ;
	} 

	public function deletable($Semester_ID = 0){
		global $database;
		$sql = "SELECT count(*) FROM subject ";
		$sql .= " WHERE Semester_ID='" . $database->escape_value($Semester_ID) . "' ";
		$sql .= "LIMIT 1";
		$result = $database->query($sql);

		return $result;	

	}

	public function deletable2($Semester_ID = 0){
		global $database;

		$sql = "SELECT count(*) FROM album ";
		$sql .= " WHERE Semester_ID='" . $database->escape_value($Semester_ID) . "' ";
		$sql .= "LIMIT 1";
		$result2 = $database->query($sql);

		return $result2;	

	}

	public static function get_all_semester(){
		$sql = "SELECT * FROM semester WHERE Profile_ID = " . $_SESSION["profile_id"] . " ORDER BY School_year, Semester_period ";	
		$semester = Semester::find_by_sql($sql);
		return $semester;
	}

	public static function get_semester_by_profile($id){
		$sql = "SELECT * FROM semester WHERE Profile_ID = " . $id . " ORDER BY School_year";	
		$semester = Semester::find_by_sql($sql);
		return $semester;
	}
  	//common database methods

}

if(isset($_SESSION['profile_id'])){ 
	$semester = Semester::get_all_semester();
	//$semester = Semester::find_by_sql($sql);
}


?>  