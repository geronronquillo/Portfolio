<?php

//require_once(LIB_PATH.DS."config.php");
require_once(LIB_PATH.DS."database.php");

class Project extends DatabaseObject {

	protected static $table_name="project";
	protected static $db_fields = array( 'Project_ID',	'File_name',	'Title',	'Subject_ID' );
	
	public $Project_ID;
	public $File_name;
	public $Title;
	public $Subject_ID;

	
	private $temp_path;
	protected $upload_dir="projects";
	public $errors = array();
	
	function __construct() {
		
	}

 	protected $upload_errors = array(
			UPLOAD_ERR_OK			=> "No errors.",
			UPLOAD_ERR_INI_SIZE  	=> "Larger than upload_max_filesize.",
		  	UPLOAD_ERR_FORM_SIZE 	=> "Larger than form MAX_FILE_SIZE.",
		  	UPLOAD_ERR_PARTIAL 		=> "Partial upload.",
		  	UPLOAD_ERR_NO_FILE 		=> "No file.",
		  	UPLOAD_ERR_NO_TMP_DIR 	=> "No temporary directory.",
		  	UPLOAD_ERR_CANT_WRITE 	=> "Can't write to disk.",
		  	UPLOAD_ERR_EXTENSION 	=> "File upload stopped by extension."
	);

	public function attach_file($file) {
		
		if(!$file || empty($file) || !is_array($file)) {
			$this->error[] = "No file was uploaded";
			return false;

		} elseif($file['error'] != 0) {
			$this->error[] = $this->upload_errors[$file['error']];
			return false; 
		} else {
			$this->temp_path	= $file['tmp_name'];
			$this->File_name	= md5(basename($file['name'])) . $file['name'] ;
			//$this->type			= $file['type'];
			//$this->size			= $file['size'];
			return true;
		}
	}

	//this method was overwritten frm the parent class. Because of error differences
	public function save() { 
		if(!empty($this->errors)) { 
			return false; 
		}


		if(empty($this->File_name) || empty($this->temp_path)) {
			$this->errors[] = "The file location was not available." . $this->File_name . $this->temp_path . "--" ;
			return false;
		}
		
		$target_path = SITE_ROOT.DS.$this->upload_dir.DS.$this->File_name; 
		if(file_exists($target_path)) {
			$this->errors[] = "The file {$this->filename} already exists.";
			return false;
		}

		if(move_uploaded_file($this->temp_path, $target_path)) {
			// Successs
			if($this->create()) {
				unset($this->temp_path);
				return true;
			}
		} else {
			$this->erros[] = "The file upload failed, possibly due to incorrect permissions on the upload folder.";
			return false;
		}

		
	}

	public function pdf_path() {
		return $this->upload_dir.'/'.$this->File_name;
	}

	public function size_as_text() {
		if($this->size < 1024) {
			return "{$this->size} bytes";
		} elseif($this->size < 1048576) {
			$size_kb = round($this->size / 1024);
			return "{$size_kb} KB";
		} else {
			$size_mb = round($this->size / 1048576, 1);
			return "{$size_mb} MB";
		}
	}



	public function date_format(){
		return date_format(date_create($this->date_posted) ,"F d, Y. D");
	}	
	public function public_date_format(){
		return date_format(date_create($this->date_posted) ,"F d, Y");
	}

	public function destroy() {
		if($this->delete()) {
			$target_path = SITE_ROOT.DS.'public'.DS.$this->pdf_path();
			return unlink($target_path) ? true : false;		
		} else {
			
		}
	}
  

	//common database methods
	
	public function update_thesis(){  //- remove this one
		global $database;
		$sql = "UPDATE thesis ";
		$sql .= "SET abstract='" . $this->abstract;
		if($this->editable()){
			$sql .= "', title='" . $database->escape_value($this->title);
			$sql .= "', adviser_id='" . $database->escape_value($this->adviser_id); 
			$sql .= "', type='" . $database->escape_value($this->type);
		}
		$sql .= "', thesis_status='" . $database->escape_value($this->thesis_status);
		$sql .= "', pdf_status='" . $database->escape_value($this->pdf_status) ;
		$sql .= "' WHERE id=". $database->escape_value($this->id);
		
		$database->query($sql);
		return ($database->affected_rows() == 1) ? 1 : 0 ;
	}
	

	public static function get_by_subject_id($subj_id){
		global $database;
		$sql = "SELECT * FROM project ";
		$sql .= "WHERE Subject_ID = " . $database->escape_value($subj_id);

		$projects = Project::find_by_sql($sql);

		return $projects;

	}

}


?>  