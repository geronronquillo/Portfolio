<?php require_once('includes/initialize.php');  ?>

<?php

if(!$session->is_logged_in()) {
  redirect_to("login.php");
}


?>




<!DOCTYPE html>
<html lang="en">
<head>
	
	<!-- start: Meta -->
	<meta charset="utf-8">
	<title>Portfolio</title>
	<meta name="description" content="Bootstrap Metro Dashboard">
	<meta name="author" content="Dennis Ji">
	<meta name="keyword" content="Metro, Metro UI, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
	<!-- end: Meta -->
	
	<!-- start: Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- end: Mobile Specific -->
	
	<!-- start: CSS -->
	<link href="css/bootstrap.css" rel="stylesheet">
    
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
    <link id="base-style" href="css/style.css" rel="stylesheet">
    <link id="base-style-responsive" href="css/style-responsive.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&subset=latin,cyrillic-ext,latin-ext' rel='stylesheet' type='text/css'>
	<!-- end: CSS -->
	

	<!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<link id="ie-style" href="css/ie.css" rel="stylesheet">
	<![endif]-->
	
	<!--[if IE 9]>
		<link id="ie9style" href="css/ie9.css" rel="stylesheet">
	<![endif]-->
		
	<!-- start: Favicon -->
	<link rel="shortcut icon" href="img/favicon.ico">
	<!-- end: Favicon -->

	
		
</head>
<body>
		<!-- start: Header -->
	<div class="navbar">
		<div class="navbar-inner">
			<div class="container-fluid">
				<a class="btn btn-navbar" data-toggle="collapse" data-target=".top-nav.nav-collapse,.sidebar-nav.nav-collapse">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a class="brand" href="index.php"><span>My Portfolio</span></a>
				


           <!--   <button class="btn btn-success" >Add Semester to the List</button>	 -->
				<!-- start: Header Menu -->
				<div class="nav-no-collapse header-nav">
					<ul class="nav pull-right">
						<!-- start: User Dropdown -->
						<li class="dropdown">
							<a class="btn dropdown-toggle" data-toggle="dropdown" href="#">
								<i class="halflings-icon white user"></i> <?php echo $profile->get_fullname(); ?>
								<span class="caret"></span>
							</a>
							<ul class="dropdown-menu">
								<li class="dropdown-menu-title">
 									<span>Account Settings</span>
								</li>
								<li><a  data-toggle="modal" data-target="#edit_pro"><i class="halflings-icon user"></i>Edit Profile</a></li>
								<li><a  data-toggle="modal" data-target="#edit_acc"><i class="halflings-icon cog"></i>Edit account</a></li>
								<li><a  href="logout.php"><i class="halflings-icon off"></i> Logout</a></li>
							</ul>
						</li>
						<!-- end: User Dropdown -->
					</ul>
				</div>
				<!-- end: Header Menu -->
				
			</div>
		</div>
	</div>
	<!-- start: Header -->
	
		<div class="container-fluid-full">
		<div class="row-fluid">
				
			<!-- start: Main Menu -->
			<div id="sidebar-left" class="span2">
				<div class="nav-collapse sidebar-nav">
					<ul class="nav nav-tabs nav-stacked main-menu">
						<li><a href="index.php"><i class="icon-user"></i><span class="hidden-tablet">Profile</span></a></li>
						<li>
							<a class="dropmenu" href="#"><i class="icon-folder-close-alt"></i><span class="hidden-tablet"> My Subjects</span></a>
							<ul>
								<?php $sem_list = []; ?>
								<?php $sy_list = []; ?>
								<?php $sem_ids = []; ?>
								<?php  while($sem = array_shift($semester)){ 

											$sy_list[] = $sem->School_year;
											$sem_list[] = $sem->Semester_period;
											$sem_ids[] = $sem->Semester_ID;
								?>


								<li style="padding-left: 10px;"><a class="dropmenu" href="#"><i class="icon-dashboard"></i><span class="hidden-tablet"> <?php echo " $sem->School_year "; ?> </span></a>
									<ul>
										<?php 
										$subject = Subject::get_all_subjects();

										while($subj = array_shift($subject)){
											if($subj->Semester_ID == $sem->Semester_ID){
											?>

											<li><a href="subject.php?subj_id=<?php echo $subj->Subject_ID;?>"><i class="icon-book"></i><span class="hidden-tablet"> <?php echo "$subj->Subject_name"; ?> </span></a></li>

											<?php 
											}
										} 
											?>
											
										<li><a class="dropmenu" data-toggle="modal" href="#<?php echo $sem->Semester_ID ;?>"><i class="icon-plus"></i><span class="hidden-tablet"> Add subject</span></a></li>
										<?php if(!array_shift($database->fetch_array($sem->deletable($sem->Semester_ID))) && !array_shift($database->fetch_array($sem->deletable2($sem->Semester_ID)))){ ?>
											<li><a class="dropmenu" data-toggle="modal" href="<?php echo '#sem'.$sem->Semester_ID ;?>"><i class="icon-minus"></i><span class="hidden-tablet"> Delete This Semester</span></a></li>
										<?php } ?>			
									</ul>
								</li>


								<?php } ?>

								 
								<li style="padding-left: 10px;"><a class="dropmenu" data-toggle="modal" data-target="#sem"><i class="icon-plus"></i><span class="hidden-tablet"> Add Semester</span></a></li>
							</ul>	
						</li>

						<li><a href="evaluation.php"><i class="icon-edit"></i><span class="hidden-tablet"> Evaluation </span></a></li>
					
						
						<!-- <li><a href="calendar.php"><i class="icon-calendar"></i><span class="hidden-tablet">Calendar Activities</span></a></li> -->
						<li><a href="photos.php"><i class="icon-picture"></i><span class="hidden-tablet"> My Photos</span></a></li>
					</ul>
				</div>
			</div>
			<!-- end: Main Menu -->
			
			<noscript>
				<div class="alert alert-block span10">
					<h4 class="alert-heading">Warning!</h4>
					<p>You need to have <a href="http://en.wikipedia.org/wiki/JavaScript" target="_blank">JavaScript</a> enabled to use this site.</p>
				</div>
			</noscript>
<!-- /.start modal sa SEM--> 

<div class="modal hide fade" id="sem">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: #c963f3;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h1 class="modal-title" id="myModalLabel">Adding Semester in a especific year</h1>
            </div>
            <div class="modal-body">


     <form role="form" action="index.php" method="POST">
	    <fieldset>




          <div class="control-group">
            <label class="control-label" for="year">Choose Semester and Year</label>
            <div class="controls">
              <select id="year" data-rel="chosen" name="School_year">
              <?php
              for($roll = 1995; $roll <= date('Y'); $roll++){
              		$a_year = $roll . "-" . ($roll+1);
              		if(!in_array('1st Sem. ' . $a_year, $sy_list)){
	              		echo "<option value='1st Sem. $a_year'>1st Sem. $a_year</option>";
	              	}
	              	if (!in_array('2nd Sem. ' . $a_year, $sy_list)) {
				        echo "<option value='2nd Sem. $a_year'>2nd Sem. $a_year</option>";
	              	}
	              	if (!in_array('Summer ' . $a_year, $sy_list)) {
				        echo "<option value='Summer $a_year'>Summer $a_year</option>";
	              	}
              }
              ?>
             
              </select>
            </div>
            
          </div>
         </br></br></br></br></br></br></br></br></br></br>
          <hr />
          <a class="btn btn-danger" data-dismiss="modal" style="width:230px">Cancel</a>
          
          <button class="btn btn-success" type="submit" name="add_sem" style="width:250px">Add Semester to the List</button>
        </fieldset>
    </form>

	                                               
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 










<?php 

	foreach($sem_ids as $sem_id){

?>


<!-- /.start modal sa SEM--> 

<div class="modal hide fade" id="<?php echo $sem_id;?>">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: #c963f3;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h1 class="modal-title" id="myModalLabel">Adding Subject</h1>
            </div>
            <div class="modal-body">



    <form role="form" action="index.php" method="POST">  
        <fieldset>
        	 </br> </br>

          	 <div class="input-prepend success" title="Subject">
	            <input class="input-large" name="Subject_name" id="sub" type="text" required="" placeholder="Subject NameSSSSSSS"/>
	         </div>

          <div class="control-group hidden-phone">
            <label class="control-label">Subject Description</label>
            <div class="controls">
            <textarea   class="input-large span12" name="Description" id="textarea2" rows="3" maxlength="80"></textarea>
            </div>
          </div>


          	 <div class="input-prepend succes" >
	            <input class="input-large" name="Unit" type="number" required="" placeholder="Units"/>
	         </div>



          <div class="control-group">
            <label class="control-label" >Grade</label>
            <div class="controls">
              <select data-rel="chosen" name="Grade">
              <?php 
              $grades = [' ','1.00','1.25','1.50','1.75','2.00','2.25','2.50','2.75','3.00','5.00','INC','DROP','ODP'];
              foreach($grades as $grade){
              	 echo "<option value='{$grade}'>{$grade}</option>";
              }
              ?>
                
              </select>
              </br> </br>
            </div>
          </div>

          <hr>
           </br> </br>
         	 <div class="input-prepend success" >
	            <input class="input-xlarge" name="Instructor_name" type="text" placeholder="Instructor Name"/>
	         </div>
	         </br>

	          <div class="input-prepend success" >
	            <input class="input-large" name="Section" type="text" placeholder="Section"/>
	         </div>
	          <div class="input-prepend success" >
	            <input class="input-large" name="Room" type="text" placeholder="Room #"/>
	         </div>
	          <div class="input-prepend success" >
	            <input class="input-large" name="Semester_ID" type="hidden" value="<?php echo $sem_id;?>"/>
	         </div>

	          </br> </br>
          <hr />
           </br> </br>
          <a class="btn btn-danger" data-dismiss="modal" style="width:240px">Cancel</a>
          <button  class="btn btn-success" style="width:240px" type="submit" name="add_subject">Add Subject to the List</button>
          
        </fieldset>
    </form>

                                               
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 


<?php } ?>







<!-- /.start modal sa ALBUM--> 

<div class="modal hide fade" id="album">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: #c963f3;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h1 class="modal-title" id="myModalLabel">Adding Album</h1>
            </div>
            <div class="modal-body">
        <fieldset>
          	 <div class="input-prepend success" title="Subject">
	            <input class="input-large" name="sub" id="sub" type="text" required="" placeholder="Album Name"/>
	         </div>
	         </br>
         	 <textarea tabindex="10" class="input-xlarge span12" id="messages" name="messages" rows="10" placeholder="Click here to create Caption."></textarea>
	          
          <hr />
          <button class="btn btn-success btn-block" type="submit" name="add_sem">Add Album</button>
        </fieldset>
                                               
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 



<!-- /.start modal sa Evaluation in Grade--> 
<?php 
$subject = Subject::get_all_subjects();
	while($subj = array_shift($subject)){
?>

<div class="modal hide fade" id="<?php echo $subj->Subject_ID; ?>">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: #c963f3;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h1 class="modal-title" id="myModalLabel">Edit Subject</h1>
            </div>
            <div class="modal-body">

    <form type="form" action="evaluation.php" method="POST">
        <fieldset>
			<input name="Subject_ID" type="hidden" required="" value="<?php echo $subj->Subject_ID; ?>"/>  
			<input name="Semester_ID" type="hidden" required="" value="<?php echo $subj->Semester_ID; ?>"/>        	
            </br> </br>

          	 <div class="input-prepend success" title="Subject">
	            <input class="input-large" name="Subject_name" id="sub" type="text" required="" value="<?php echo $subj->Subject_name; ?>" placeholder="Subject Name"/>
	         </div>

          <div class="control-group hidden-phone">
            <label class="control-label">Subject Description</label>
            <div class="controls">
            <textarea   class="input-large span12" name="Description" id="textarea2" rows="3" maxlength="80"><?php echo $subj->Description; ?></textarea>
            </div>
          </div>


          	 <div class="input-prepend succes" >
	            <input class="input-large" name="Unit" type="number" required="" value="<?php echo $subj->Unit; ?>" placeholder="Units"/>
	         </div>



          <div class="control-group">
            <label class="control-label" >Grade</label>
            <div class="controls">
              <select data-rel="chosen" name="Grade">
              <?php 
              $grades = ['', '1.00','1.25','1.50','1.75','2.00','2.25','2.50','2.75','3.00','5.00','INC','DROP','ODP'];
              foreach($grades as $grade){
              	 echo "<option value='{$grade}'";
              	 if($subj->Grade == $grade){ echo " Selected ";}
              	 echo ">{$grade}</option>";
              }
              ?>
                
              </select>
              </br> </br>
            </div>
          </div>

          <hr>
           </br> </br>

           <?php if($subj->Grade == "INC"){ ?>

         <div class="control-group">
           
            <label class="control-label" >Grade Completion (If Grade is INC)</label>
            <div class="controls">
              <select data-rel="chosen" name="Grade_com">
              <option value="" selected disabled>Select Your Completion Grade</option>
              <?php 
              $grades = ['1.00','1.25','1.50','1.75','2.00','2.25','2.50','2.75','3.00','5.00','DROP'];
              foreach($grades as $grade){
              	 echo "<option value='{$grade}'";
              	 if($subj->Complete_grade == $grade){ echo " selected ";}
              	 echo ">{$grade}</option>";
              }
              ?>
                
              </select>
              </br> </br>
            </div>
          </div>
	          </br> </br>
          <hr />

          <?php } ?>
           </br> </br>
          <a class="btn btn-danger" data-dismiss="modal" style="width:240px">Cancel</a>
          <button  class="btn btn-success" style="width:240px" type="submit" name="add_subject">Save Changes</button>
        </fieldset>
        </form>
                                               
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 
<?php } ?>



<!-- /.start modal sa Evaluation in Grade delete--> 

<?php

	$subject = Subject::get_all_subjects();
	while($subj = array_shift($subject)){
?>

<div class="modal hide fade" id="delete_grade<?php echo $subj->Subject_ID?>">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: #c963f3;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h2 class="modal-title" id="myModalLabel">Are you sure you want to delete the subject?</h2>
            </div>
            <div class="modal-body">
        <fieldset>
          <a class="btn btn-danger" data-dismiss="modal" style="width:240px">Cancel </a>
          <a href="delete_subject.php?Subject_ID=<?php echo $subj->Subject_ID; ?>"><button class="btn btn-success" type="submit" name="add_sem" style="width:260px">Delete</button></a>
        </fieldset>
                                               
            </div>
        </div>

        <!-- /.modal-content -->

    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 
<?php } ?>




<!-- /.start modal sa Evaluation in privacy--> 
	<div class="modal hide fade" id="privacy_pro">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3>Settings</h3>
		</div>
		<div class="modal-body">
			<div class="control-group">
            <label class="control-label" for="sem">Choose Status in this page</label>

        <form action="change_privacy.php" method="POST">

            <div class="controls">
              <select id="pivacy_pro" data-rel="chosen" name="privacy_profile">
	              <option value="private" <?php echo ($profile->Privacy == 'private')? 'selected':''; ?>>Private</option>
	              <option value="public" <?php echo ($profile->Privacy == 'public')? 'selected':''; ?>>Public</option>
              </select>
            </div>
            </br></br></br></br><hr />
          </div>
		 
          <a class="btn btn-danger" data-dismiss="modal" style="width:240px">Cancel</a>
          <button class="btn btn-success" type="submit" name="change_privacy" style="width:260px">Change</button>
        </form>

        </div>
	</div>
<!-- /.modal --> 


<!-- /.start modal sa Evaluation in privacy--> 
	<div class="modal hide fade" id="privacy_eval">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3>Settings</h3>
		</div>
		<div class="modal-body">
			<div class="control-group">
            <label class="control-label" for="sem">Choose Status in this pagessss</label>

        <form action="change_privacy.php" method="POST">

            <div class="controls">
              <select id="pivacy_eval" data-rel="chosen" name="privacy_eval">
	              <option value="private" <?php echo ($profile->Privacy_eval == 'private')? 'selected':''; ?>>Private</option>
	              <option value="public" <?php echo ($profile->Privacy_eval == 'public')? 'selected':''; ?>>Public</option>
	   
              </select>
            </div>
            </br></br></br></br><hr />
          </div>
		 
          <a class="btn btn-danger" data-dismiss="modal" style="width:240px">Cancel</a>
          <button class="btn btn-success" type="submit" name="change_privacy" style="width:260px">Change</button>
        </form>

        </div>
	</div>
<!-- /.modal --> 


<!-- /.start modal sa delete Sem--> 
<?php 
	foreach($sem_ids as $sem_id){
	$semester = new Semester();
	if($semester->deletable($sem_id)){
?>

<div class="modal hide fade" id="<?php echo 'sem'.$sem_id; ?>">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: #c963f3;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h2 class="modal-title" id="myModalLabel">Are you sure you want to delete the Semester? with id= <?php echo $sem_id; ?></h2>
            </div>
            <div class="modal-body">
        <fieldset>
          <a class="btn btn-danger" data-dismiss="modal" style="width:240px">Cancel</a>
          <a href="delete_semester.php?sem_id=<?php echo $sem_id ?>" ><button class="btn btn-success" type="submit" name="add_sem"  style="width:260px">Delete</button></a>
        </fieldset>
                                               
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal -->  

<?php }} ?>



	<div class="modal hide fade" id="edit_pro">
		<div class="modal-header" style="background-color: #c963f3;">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h2>Edit Profile</h2>
		</div>

		<form action="edit_profile.php" method="POST">

		<div class="modal-body">
		Firstname:</br>
			<div class="input-prepend success" title="Fname">
            <input class="input-large span20" style="width:240px" name="Fname" id="Fname" type="text" required="" placeholder="First Name " value="<?php echo $profile->First_name;?>"/>
          </div></br>
          Middlename:</br>
          <div class="input-prepend success" title="Mname">
            <input class="input-large span20" style="width:240px" name="Mname" id="Mname" type="text" required="" placeholder="Middle Name " value="<?php echo $profile->Middle_name;?>"/>
          </div></br>
          Lastname:</br>
          <div class="input-prepend success" title="Lname">
            <input class="input-large span20" style="width:240px" name="Lname" id="Lname" type="text" required="" placeholder="Last Name " value="<?php echo $profile->Last_name;?>"/>
          </div>

          <div class="control-group">
            <label class="control-label" for="Gender">Gender</label>
            <div class="controls">
              <select id="Gender" data-rel="chosen" name="Gender">
                <option value="male" <?php echo ($profile->Gender == 'male')? 'selected':'' ; ?>>Male</option>
                <option value="female" <?php echo ($profile->Gender == 'female')? 'selected':'' ; ?>>Female</option>
              </select>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label">Birth Date</label>
            <div class="controls">
              <input type="text" class="input-xlarge datepicker" name="Birthdate" id="date02" value="<?php echo datetime_to_birthdate($profile->Birthdate); ?>">
            </div>
          </div>
          Email:</br>
          <div class="input-prepend success" >
            <input class="input-large span20" style="width:240px" name="Email" type="email" required="" placeholder="Email Address" value="<?php echo $profile->Email_address;?>"/>
          </div>
          </br>
          Address:</br>
          <div class="input-prepend success" title="Address">
            <input class="input-large span20" style="width:240px"  name="Address" id="Address" type="text" required="" placeholder="Address " value="<?php echo $profile->Address;?>"/>
          </div>
</br>
		  Contact:</br>
          <div class="input-prepend success" title="contact">
            <input class="input-large span20" style="width:240px"  name="Contact" id="contact" type="text" required="" placeholder="Contact " value="<?php echo $profile->Contact_number;?>"/>
          </div>
</br>
          <div class="control-group hidden-phone">
            <label class="control-label" for="textarea3">About Me</label>
            <div class="controls">
            <textarea   class="input-large span10" name="about_me" id="textarea3" rows="3" maxlength="300"><?php echo $profile->About_me;?></textarea>
            </div>
          </div>
		</div>
		<div class="modal-footer">
			<a class="btn btn-danger" data-dismiss="modal" style="width:240px">Cancel</a>
            <button class="btn btn-success" type="submit" name="edit_profile" style="width:250px">Change</button>
		</div>

		</form>

	</div>




	<div class="modal hide fade" id="edit_acc">
		<form action="index.php" method="POST">

			<div class="modal-header" style="background-color: #c963f3;">
				<button type="button" class="close" data-dismiss="modal">×</button>
				<h2>Edit Account</h2>
			</div>
			<div class="modal-body">
				<p>
			Current Password:</br>
	          <div class="input-prepend success" title="password1">
	            <input class="input-large span15" style="width:240px" name="old_password" id="password1" type="password" required="" placeholder="Current Password "/>
	          </div>
	          <hr />
			</br>New Password:</br>
	          <div class="input-prepend success" title="password2">
	            <input class="input-large span15" style="width:240px" name="new_password1" id="password2" type="password" required="" placeholder="New Password "/>
	          </div>
	        </br>Confirm Password:</br>
	          <div class="input-prepend success" title="password3">
	            <input class="input-large span15" style="width:240px" name="new_password2" id="password3" type="password" required="" placeholder="Confirm Password "/>
	          </div>
	          </p>
			</div>
			<div class="modal-footer">
				<a class="btn btn-danger" data-dismiss="modal" style="width:240px">Cancel</a>
	            <button class="btn btn-success" type="submit" name="edit_account" style="width:250px">Change</button>
			</div>
		</form>
	</div>

<!-- /.start modal sa Subject in file delete--> 
<?php 
if(isset($_GET['subj_id'])){
	$subj_id = $_GET['subj_id'];
	$projects = Project::get_by_subject_id($subj_id);
	foreach($projects as $project){
?>


<div class="modal hide fade" id="<?php echo $project->Project_ID;?>delete_file">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: #c963f3;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h2 class="modal-title" id="myModalLabel">Are you sure you want to delete the File?</h2>
            </div>
            <div class="modal-body">
        <fieldset>
          <a class="btn btn-danger" data-dismiss="modal" style="width:240px">Cancel</a>
          <a href="delete_project.php?<?php echo 'proj_id='. $project->Project_ID . '&subj_id=' . $subj_id ;?>"><button class="btn btn-success" type="submit" name="delete_file" style="width:250px">Delete</button></a>
        </fieldset>
                                               
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 
<?php }} ?>


<!-- /.start modal sa Subject in Add Album--> 
<?php 

	$semester = Semester::get_all_semester();
	foreach($semester as $sem){
?>


<div class="modal hide fade" id="<?php echo $sem->Semester_ID;?>add_album">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: #c963f3;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h2 class="modal-title" id="myModalLabel">Adding Album</h2>
            </div>
            <div class="modal-body">
            <form action="add_album.php" method="POST">
            	 </br>Album Name:</br>
		          <div class="input-prepend success" title="txt3">
		            <input class="input-large span15" style="width:270px" name="Album_name" id="txt3" type="text" required="" placeholder="Album Name "/>
		          </div>
		          </p>
					
					<input type="hidden" name="Semester_ID" value="<?php echo $sem->Semester_ID;?>"/>
		          <a class="btn btn-danger" data-dismiss="modal" style="width:240px">Cancel</a>
		          <button class="btn btn-success" type="submit" name="submit_album" style="width:250px">Confirm</button>
            </form>                                   
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 

<?php } ?>

<!-- /.start modal sa Subject in Album delete--> 
<?php 
$albums = Album::find_all();
foreach ($albums as $album) {
?>
<div class="modal hide fade" id="<?php echo $album->Album_ID;?>delete_album">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: #c963f3;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h2 class="modal-title" id="myModalLabel">Are you sure you want to delete the Album?</h2>
            </div>
            <div class="modal-body">
        <fieldset>
          <a class="btn btn-danger" data-dismiss="modal" style="width:240px">Cancel</a>
          <a href="delete_album.php?album_id=<?php echo $album->Album_ID;?>"><button class="btn btn-success" type="submit" name="delete_file" style="width:250px">Delete</button></a>
        </fieldset>
                                               
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 
<?php } ?>

<?php 

$photos = Photo::find_all();

foreach ($photos as $photo) {
?>
<!-- /.start modal sa Subject in Photo delete--> 

<div class="modal hide fade" id="<?php echo $photo->Photo_ID; ?>delete_photo">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: #c963f3;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h2 class="modal-title" id="myModalLabel">Are you sure you want to delete the Photo?</h2>
            </div>
            <div class="modal-body">
        <fieldset>
          <a class="btn btn-danger" data-dismiss="modal" style="width:240px">Cancel</a>
          <a href="delete_photo.php?photo_id=<?php echo $photo->Photo_ID . "&album_id=" . $photo->Album_ID; ?>"><button class="btn btn-success" type="submit" name="delete_file" style="width:250px">Delete</button></a>
        </fieldset>
                                               
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 
<?php } ?>


<!-- /.start modal sa Subject in addpic--> 

<?php 
$albums = Album::find_all();
foreach ($albums as $album) {
?>

<div class="modal hide fade" id="<?php echo $album->Album_ID; ?>add_pic">
   <div class="modal-dialog">
        <div class="modal-content" style="background-color: #c963f3;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h1 class="modal-title" id="myModalLabel">Upload Picture</h1>
            </div>
            <div class="modal-body">



	 <form action="add_photo.php" enctype="multipart/form-data" method="POST">

                    <div class="control-group">
					  </br></br>

						<input type="hidden" name="MAX_FILE_SIZE" value="<?php echo "1000000"; ?>" />
						<input type="hidden" name="Album_ID" value="<?php echo $album->Album_ID; ?>" />

						<input type="hidden" name="Subject_ID" value="<?php echo $subj_id; ?>"/>
						<input type="file" name="file_upload[]" class="btn btn-default btn-flat" required multiple/><br />
					 	
					 	<!-- <a href="add_project.php" class="btn btn-primary" style="margin-top: -50px; margin-left: 200px;">Add File</a> -->
					 	
				        </br></br>

					</div>
          <hr />
          <a class="btn btn-danger" data-dismiss="modal" style="width:240px">Cancel</a>
          <button  class="btn btn-success" style="width:240px" type="submit" name="add_photos"> Upload </button>
          
    </form>

                                               
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 
<?php } ?>



<!-- /.start modal sa Subject in Search friend--> 
<!-- 
<div class="modal hide fade" id="search_friend">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: #c963f3;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h2 class="modal-title" id="myModalLabel">Hi i am Geron Ronquiilo </h2>
            </div>
            <div class="modal-body">
        <fieldset>
          <a class="btn btn-danger" data-dismiss="modal" style="width:240px">Cancel</a>
          <button class="btn btn-success" type="submit" name="delete_file" style="width:250px">Delete</button>
        </fieldset>
                                               
            </div>
        </div>
        <!/.modal-content -->
    <!-- </div> -->
    <!-- /.modal-dialog -->
<!-- </div> -->
<!-- /.modal -->  



<!-- /.start modal sa Subject in Search friend--> 
<?php
//manual code here.
    $profile_list = Profile::find_all();
    while($profile1 = array_shift($profile_list)){


?>


<div class="modal hide fade" id="search_friend" style="width: 1190px; margin-left: -600px;">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: #c963f3;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h2 class="modal-title" id="myModalLabel">My Evaluation</h2>
            </div>
            <div class="modal-body">
        <fieldset>
        <div class="well bs-component" style="background-color:black">
            <div class="bs-component">
              <ul class="nav nav-tabs">
                <li class="active"><a href="#INFO" data-toggle="tab">About me</a></li>
                <li><a href="#EVALUATION" data-toggle="tab">Evaluation</a></li>
              </ul>
              <div id="myTabContent" class="tab-content">
                <div class="tab-pane fade active in" id="INFO">
                  <p>
                    <h2>
                    Picture:
            <hr />
            Name:  <hr /> 
            Birthdate: <hr />
            Gender:<hr />
            Address:<hr />
            Contact Number: <hr />
            About Me: <hr />

            </h2>
                  </p>
                </div>
                 
                 <div class="tab-pane fade" id="EVALUATION">
                  <p>
                   
      <div class="row-fluid sortable">
        <div class="box span6">
          <div class="box-header">
            <h2><i class="halflings-icon align-justify"></i><span class="break"></span>Simple Table</h2>
          </div>
          <div class="box-content">
            <table class="table">
                <thead>
                  <tr>
                    <th>Username</th>
                    <th>Date registered</th>
                    <th>Role</th>
                    <th>Status</th>                                          
                  </tr>
                </thead>   
                <tbody>
                <tr>
                  <td>Dennis Ji</td>
                  <td class="center">2012/01/01</td>
                  <td class="center">Member</td>
                  <td class="center">
                    <span class="label label-success">Active</span>
                  </td>                                       
                </tr>
                                                   
                </tbody>
             </table>  
                 
          </div>
        </div><!--/span-->
        
        <div class="box span6">
          <div class="box-header">
            <h2><i class="halflings-icon align-justify"></i><span class="break"></span>Striped Table</h2>
          </div>
          <div class="box-content">
            <table class="table table-striped">
                <thead>
                  <tr>
                    <th>Username</th>
                    <th>Date registered</th>
                    <th>Role</th>
                    <th>Status</th>                                          
                  </tr>
                </thead>   
                <tbody>
                <tr>
                  <td>Dennis Ji</td>
                  <td class="center">2012/01/01</td>
                  <td class="center">Member</td>
                  <td class="center">
                    <span class="label label-success">Active</span>
                  </td>                                       
                </tr>
                                                   
                </tbody>
             </table>  
             
          </div>
        </div><!--/span-->
      </div><!--/row-->
                  </p>
                </div>
                
                
              </div>

          </div>
          </div>
        </fieldset>
                                               
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 

<?php } ?>
