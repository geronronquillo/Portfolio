<?php

//require_once(LIB_PATH.DS."config.php");
require_once(LIB_PATH.DS."database.php");

class Album extends DatabaseObject {

	protected static $table_name="album";
	protected static $db_fields = array( "Album_ID", "Album_name", 	"status", 	"Date_added" , "Semester_ID" );
	public $Album_ID;
	public $Album_name; 		
	public $status;
	public $Date_added = 'NULL';
	public $Semester_ID;
	

	public static function find_by_semester_id($sem_id){
		$sql = "SELECT * FROM album ";		
		$sql .= "WHERE Semester_ID=" . $sem_id;
		$albums = Album::find_by_sql($sql);
		return $albums;
	}

	public function deletable(){
		global $database;
		$sql = "SELECT * FROM photo WHERE Album_ID=" . $this->Album_ID;
		$result = $database->query($sql);
		return mysql_fetch_array($result);
	}

	public static function find_by_id($id=0) {
		global $database;
		$result_array = Album::find_by_sql("SELECT * FROM album WHERE Album_ID=".$database->escape_value($id)." LIMIT 1");
 
		return !empty($result_array) ? array_shift($result_array) : false;
	}
	

}

if(isset($_SESSION['profile_id'])){
		
}

?>