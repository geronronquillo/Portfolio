<?php

//remember that this DS was not used in the image path method because web browsers act differently when it comes to Path directories. :)

defined('DS') ? null : define('DS', DIRECTORY_SEPARATOR);


defined('SITE_ROOT') ? null : 
	define('SITE_ROOT', 
	'C:'.DS.'xampp'.DS.'htdocs'.DS.'PORTFOLIO'); 

defined('LIB_PATH') ? null : define('LIB_PATH', SITE_ROOT.DS.'includes');


require_once(LIB_PATH.DS."config.php");

require_once(LIB_PATH.DS."functions.php");

require_once(LIB_PATH.DS."session.php");

require_once(LIB_PATH.DS."database_object.php");

require_once(LIB_PATH.DS."database.php");





 require_once(LIB_PATH.DS."profile.php");

 require_once(LIB_PATH.DS."subject.php");

 require_once(LIB_PATH.DS."semester.php");

 require_once(LIB_PATH.DS."upload_project.php");
 
 require_once(LIB_PATH.DS."album.php");

 require_once(LIB_PATH.DS."photo.php");
?>