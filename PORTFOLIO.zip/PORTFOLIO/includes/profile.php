<?php

//require_once(LIB_PATH.DS."config.php");
require_once(LIB_PATH.DS."database.php");

class Profile extends DatabaseObject {

	protected static $table_name="profile"; 
	protected static $db_fields = array('Profile_ID', 'First_name', 'Middle_name', 'Last_name', 
												'Birthdate', 'Gender', 'About_me' , 'Address', 'Username', 
												'Password', 'Contact_number', 'Email_address', 'Picture' , 'Privacy', 'Privacy_eval'); 
	public $Profile_ID; 
	public $First_name;
	public $Middle_name;
	public $Last_name;
	public $Birthdate;
	public $Gender;
	public $About_me;
	public $Address;
	public $Username;
	public $Password;
	public $Contact_number;
	public $Email_address;
	public $Picture;
	public $Privacy;
	public $Privacy_eval;

	function __construct() {
		
	}
 
	public static function authenticate($username = "", $password = "") {
		global $database;

		$username = $database->escape_value($username);
		$password = $database->escape_value($password);

		$sql = "SELECT * FROM profile ";
		$sql .= "WHERE username ='{$username}' ";
		$sql .=  "AND password = '{$password}' ";
		$sql .= "LIMIT 1 ";

		$result_array = self::find_by_sql( $sql );

		return !empty($result_array) ? array_shift($result_array) : false;
	}



	public function get_fullname(){
		return $this->First_name . " " . $this->Middle_name . " " . $this->Last_name;

	}
  	//common database methods

}


if(isset($_SESSION['profile_id'])){ 
	$sql = "SELECT * FROM profile ";
	$sql .= "WHERE profile_id=" . $database->escape_value($_SESSION['profile_id']);
	$profile = array_shift(Profile::find_by_sql($sql));
}
?>  