$(document).ready(function () {
});

function addAlbum(){
    
    var albumName = $("#album_name").val();
    var activityID = $("#selected_activity").val();
    
    $.ajax({
        url: 'includes/galleryConnections.php',
        type: 'post',
        data: {'action': 'addAlbum', 'albumName': albumName, 'activityID': activityID},
        success: function(data) {
            if (data == 'success') {
                alert("You have successfully created your Album@");
                window.location = ("gallery.php");
            } else{
                alert(data);
                window.location = ("gallery.php");
            }
        }, error: function(xhr, desc, err) {
            alert("Failed to create album!");
        }
    });
}
