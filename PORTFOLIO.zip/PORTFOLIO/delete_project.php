<?php require_once('includes/initialize.php');  ?>

<?php

if($session->is_logged_in()) {
    if(isset($_GET['subj_id']) && isset($_GET['proj_id']))   {

	  $project = Project::find_project_by_id($_GET['proj_id']);
      if($project->destroy()){
          redirect_to('subject.php?subj_id=' . $_GET['subj_id']);
      }

    }
 
}




?>