<?php require_once('includes/initialize.php');  ?>

<?php 

$message = "";
$message = $session->message;

?>

<?php include("includes/header.php"); ?>




			<!-- start: Content -->
			<div id="content" class="span10">
			
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.php">Home</a> 
					<i class="icon-angle-right"></i>
					Photos
				</li>
				
			</ul>
  			
  			<?php 
                if($message > " "){
            ?>
            <div class="alert alert-error">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong> 
                <?php 
                        echo $message;

                ?>
            </div>
            <?php } ?>
		


			<?php 

			$semester = Semester::get_all_semester();
			foreach($semester as $sem){

			?>
			<div class="row-fluid">	
				<div class="box green span12">
					<div class="box-header">
						<h2><i class="halflings-icon th-list"></i><span class="break"></span><?php echo $sem->School_year;?></h2>
						
					</div>
					<div class="box-content">
						
						<a class="quick-button span2 btn-success" data-toggle="modal" href="#<?php echo $sem->Semester_ID;?>add_album" style="width:145px; height:130px; margin:10px">
							<i class="icon-plus" style="margin-top:10px"></i>
							<p>Add Album</p>
						</a>

						<?php
						$albums = Album::find_by_semester_id($sem->Semester_ID);
						foreach ($albums as $album) { ?>

						<a href="picture.php?album_id=<?php echo $album->Album_ID;?>" class="quick-button span2 btn-info" style="width:145px; height:130px; margin:10px">
							<i class="icon-picture" style="margin-top:10px"></i>
							<p><?php echo $album->Album_name?></p>
							<?php if(!$album->deletable()){ ?>
							<span data-toggle="modal" href="#<?php echo $album->Album_ID; ?>delete_album" class="btn notification red">delete</span>
							<?php } ?>
						</a>
						
						<?php } ?>

						

						
						<div class="clearfix"></div>



					</div>	
				</div><!--/span-->
				
			</div><!--/row-->

			<?php } ?>

 

			</div>
			<!-- end: Content -->
		</div>
	</div><!--/fluid-row-->
	
		
	<div class="modal hide fade" id="myModal">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3>Settings</h3>
		</div>
		<div class="modal-body">
			<p>Here settings can be configured...</p>
		</div>
		<div class="modal-footer">
			<a href="#" class="btn" data-dismiss="modal">Close</a>
			<a href="#" class="btn btn-primary">Save changes</a>
		</div>
	</div>
	
	<div class="clearfix"></div>
    <footer id="footer" class="navbar navbar-default">
       <?php include("includes/footer.php"); ?>	
    </footer>

	
	<!-- start: JavaScript-->

		<script src="js/jquery-1.9.1.min.js"></script>
	<script src="js/jquery-migrate-1.0.0.min.js"></script>
	
		<script src="js/jquery-ui-1.10.0.custom.min.js"></script>
	
		<script src="js/jquery.ui.touch-punch.js"></script>
	
		<script src="js/modernizr.js"></script>
	
		<script src="js/bootstrap.min.js"></script>
	
		<script src="js/jquery.cookie.js"></script>
	
		<script src='js/fullcalendar.min.js'></script>
	
		<script src='js/jquery.dataTables.min.js'></script>

		<script src="js/excanvas.js"></script>
	<script src="js/jquery.flot.js"></script>
	<script src="js/jquery.flot.pie.js"></script>
	<script src="js/jquery.flot.stack.js"></script>
	<script src="js/jquery.flot.resize.min.js"></script>
	
		<script src="js/jquery.chosen.min.js"></script>
	
		<script src="js/jquery.uniform.min.js"></script>
		
		<script src="js/jquery.cleditor.min.js"></script>
	
		<script src="js/jquery.noty.js"></script>
	
		<script src="js/jquery.elfinder.min.js"></script>
	
		<script src="js/jquery.raty.min.js"></script>
	
		<script src="js/jquery.iphone.toggle.js"></script>
	
		<script src="js/jquery.uploadify-3.1.min.js"></script>
	
		<script src="js/jquery.gritter.min.js"></script>
	
		<script src="js/jquery.imagesloaded.js"></script>
	
		<script src="js/jquery.masonry.min.js"></script>
	
		<script src="js/jquery.knob.modified.js"></script>
	
		<script src="js/jquery.sparkline.min.js"></script>
	
		<script src="js/counter.js"></script>
	
		<script src="js/retina.js"></script>

		<script src="js/custom.js"></script>
	<!-- end: JavaScript-->
	
</body>
</html>