<?php require_once('includes/initialize.php');  ?>

<?php 

if( $session->is_logged_in() && isset($_POST['add_photos'])){

	// for($roll = 0; $roll < sizeof($_FILES); $roll++){
	// 	print_r($_FILES['file_upload'] );
	// }
	//print_r($_FILES['file_upload']);
	$FILES = [];
	for($roll = 0; !empty($_FILES['file_upload']['name'][$roll]); $roll++){ 
	 	$FILES[] = ['name'	 	=> $_FILES['file_upload']['name'][$roll],
	 			 	'type' 		=> $_FILES['file_upload']['type'][$roll],
	 			 	'tmp_name'	=> $_FILES['file_upload']['tmp_name'][$roll],
	 			 	'error' 	=> $_FILES['file_upload']['error'][$roll],
	 			 	'size' 		=> $_FILES['file_upload']['size'][$roll] ];
	 //	echo "-".$_FILES['file_upload']['size'][$roll] . "-";
	 }

	//print_r($FILES);
	foreach ($FILES as $FILE) {
		$photo = new Photo();
		$photo->Album_ID =  $database->escape_value($_POST["Album_ID"]);


		 if( $FILE['type'] == "image/jpg" || $FILE['type'] == "image/jpeg" || $FILE['type'] == "image/png"   || $FILE['type'] == "image/gif" ){
			if($photo->attach_file($FILE) && $photo->save()){
				$session->message("Photo/s Successfully Added !");

			}	else {
				$session->message("Failed to upload photos !");
			}
		}

	}
	redirect_to('picture.php?album_id=' . $photo->Album_ID);

}



?>