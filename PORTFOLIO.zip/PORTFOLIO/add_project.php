<?php require_once('includes/initialize.php');  ?>

<?php 

if( $session->is_logged_in() && isset($_POST['submit_project'])){

	$project = new Project();
	$project->File_name ;
	$project->Title = $database->escape_value($_POST["title"]);
	$project->Subject_ID = $database->escape_value($_POST["Subject_ID"]);



	 if( $_FILES['file_upload']['type'] == "application/octet-stream" || $_FILES['file_upload']['type'] == "application/x-zip-compressed" ){
		if($project->attach_file($_FILES['file_upload']) && $project->save()){
			$session->message("Successfully Added Project!");

			redirect_to('subject.php?subj_id=' . $project->Subject_ID );
		}

	} 
	else {
		$session->message("Projects that can be uploaded are compressed files only!");	
		redirect_to('subject.php?subj_id=' . $project->Subject_ID );
	}
	// echo "<pre>";
	// print_r($_FILES);
	// echo "</pre>";
}



?>