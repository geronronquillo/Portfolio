<?php require_once('includes/initialize.php');  ?>

<?php

if($session->is_logged_in()) {
	if (isset($_POST['edit_profile'])) {

      
      $fname = $database->escape_value(trim($_POST['Fname']));
      $mname = $database->escape_value(trim($_POST['Mname']));
      $lname = $database->escape_value(trim($_POST['Lname']));
      
      $gender = $database->escape_value(trim($_POST['Gender']));
      $birthdate = birthdate_to_datetime($database->escape_value(trim($_POST['Birthdate'])));
      $email = $database->escape_value(trim($_POST['Email']));
      $address = $database->escape_value(trim($_POST['Address']));
      $contact = $database->escape_value(trim($_POST['Contact']));
      $about_me = $database->escape_value(trim($_POST['about_me']));




      $profile->First_name = $fname;
      $profile->Middle_name = $mname;
      $profile->Last_name = $lname;

      $profile->Gender = $gender;
      $profile->Birthdate = $birthdate;
      $profile->Email_address = $email;
      $profile->Address = $address;
      $profile->Contact_number = $contact;
      $profile->About_me = $about_me;

      if($profile->update_profile()){
      		redirect_to('index.php');
      }
  }


}




?>