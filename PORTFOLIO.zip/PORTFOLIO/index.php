<?php require_once('includes/initialize.php');  ?>

<?php 
$message = "";
if(isset($_POST['add_sem'])){
	$semester = new Semester();
	$acad_year = trim($_POST["School_year"]);
	$semester->School_year 			=	$acad_year; 
	$semester->Profile_ID 			= $profile->Profile_ID;
	if($semester->save()){
		$sql = "SELECT * FROM semester WHERE Profile_ID = " . $_SESSION["profile_id"] . " ORDER BY School_year, Semester_period ";
		$semester = Semester::find_by_sql($sql);		
		
        
        $message = "Sucessfully added  " . $_POST['School_year']; // "HELLO {$VAR}" // "hELLO $var" // "hello " . $var; 
	} else {
        $message = "Failed To Add! "; 
        
    }

}

if(isset($_POST['add_subject'])){
	$add_subject 					= new Subject();
 
	$add_subject->Subject_name  	= trim($_POST['Subject_name']);
	$add_subject->Description  		= trim($_POST['Description']);
	$add_subject->Unit  			= trim($_POST['Unit']);
	$add_subject->Grade  			= trim($_POST['Grade']);
	$add_subject->Instructor_name  	= trim($_POST['Instructor_name']);
	$add_subject->Section  			= trim($_POST['Section']);
	$add_subject->Room 	 			= trim($_POST['Room']);
	$add_subject->Profile_ID 		= $profile->Profile_ID ;
	$add_subject->Semester_ID  		= trim($_POST['Semester_ID']) ;

	if($add_subject->save()){
        
        $message = "Successfully added the new subject ". $_POST['Subject_name']  ; 

	} else {
        $message = "Failed to add the new subject! ";
    }
} 


if(isset($_POST['edit_account'])){
	if(($_POST['old_password'] == $profile->Password) && ($_POST['new_password1'] == $_POST['new_password2'])){
		

		$sql = "UPDATE profile SET Password='" . $database->escape_value($_POST['new_password1'] );
		$sql .= "' WHERE Profile_ID=" . $profile->Profile_ID;
		if($database->query($sql)){
			$message = "Successfully updated Account Password.";
		} else {
			$message = "Failed to update Password, check the passwords that you have entered.";
		}

	} else {
			$message = "Failed to update Password, check the passwords that you have entered.";
	}
}



// if(isset($session->message)){
// 	$message =  $session->message;
// }

?>

<?php include("includes/header.php"); ?>




			<!-- start: Content -->
			<div id="content" class="span10">
			
				
				<ul class="breadcrumb">
					<li>
						<i class="icon-home"></i>
						<a href="index.php">Home</a> 
						<i class="icon-angle-right"></i>
					</li>
					
				</ul>
			<div>
                
            <?php 
                if($message > " "){
            ?>
            <div class="alert alert-error">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong> 
                <?php 
                        echo $message;
                ?>
            </div>
            <?php } ?>
				
			</div>

			<div class="row-fluid sortable">		
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon user"></i><span class="break"></span>Profile</h2>
						
					</div>
					
  <div class="well" style="background-color:gray; text-align:center;">
 
          	<?php echo '<img src="data:image/jpeg;base64,'.base64_encode( $profile->Picture ).'" height="200" width="150">' ?> </br>
          	<form action="add_profile_photo.php" enctype="multipart/form-data" method="POST">
              <div class="control-group">
                <label class="control-label" for="fileInput">Profile Picture:</label>
                <div class="controls">
                <input class="input-file uniform_on" id="fileInput" type="file" name="photo" required>
                </div>

          <button  class="btn btn-success" style="width:240px" type="submit" name="add_profile_photo"> Upload </button>
              </div>  
             </form>



          	
          	<h2>
          	<hr />
          	Name: <?php echo $profile->get_fullname() .  "</br>"; ?> <hr /> 
          	Birthdate: <?php echo datetime_to_text($profile->Birthdate) . "</br>"; ?> <hr />
          	Gender: <?php echo $profile->Gender . "</br>"; ?><hr />
          	Address: <?php echo $profile->Address . "</br>"; ?><hr />
          	Contact Number: <?php echo $profile->Contact_number . "</br>"; ?><hr />
          	About Me: <?php echo $profile->About_me . "</br>" ;?><hr />

          	</h2>
  </div>
 



        
					  </table>            
					</div>
				</div><!--/span-->
			
			</div><!--/row-->
	</div><!--/.fluid-container-->
	
			<!-- end: Content -->
		</div><!--/#content.span10-->
		</div><!--/fluid-row-->
	
		
	<div class="modal hide fade" id="myModal">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3>Settings</h3>
		</div>
		<div class="modal-body">
			<p>Here settings can be configured...</p>
		</div>
		<div class="modal-footer">
			<a href="#" class="btn" data-dismiss="modal">Close</a>
			<a href="#" class="btn btn-primary">Save changes</a>
		</div>
	</div>
	
	<div class="clearfix"></div>
    <footer id="footer" class="navbar navbar-default">
       <?php include("includes/footer.php"); ?>	
    </footer>

	
	<!-- start: JavaScript-->

		<script src="js/jquery-1.9.1.min.js"></script>
	<script src="js/jquery-migrate-1.0.0.min.js"></script>
	
		<script src="js/jquery-ui-1.10.0.custom.min.js"></script>
	
		<script src="js/jquery.ui.touch-punch.js"></script>
	
		<script src="js/modernizr.js"></script>
	
		<script src="js/bootstrap.min.js"></script>
	
		<script src="js/jquery.cookie.js"></script>
	
		<script src='js/fullcalendar.min.js'></script>
	
		<script src='js/jquery.dataTables.min.js'></script>

		<script src="js/excanvas.js"></script>
	<script src="js/jquery.flot.js"></script>
	<script src="js/jquery.flot.pie.js"></script>
	<script src="js/jquery.flot.stack.js"></script>
	<script src="js/jquery.flot.resize.min.js"></script>
	
		<script src="js/jquery.chosen.min.js"></script>
	
		<script src="js/jquery.uniform.min.js"></script>
		
		<script src="js/jquery.cleditor.min.js"></script>
	
		<script src="js/jquery.noty.js"></script>
	
		<script src="js/jquery.elfinder.min.js"></script>
	
		<script src="js/jquery.raty.min.js"></script>
	
		<script src="js/jquery.iphone.toggle.js"></script>
	
		<script src="js/jquery.uploadify-3.1.min.js"></script>
	
		<script src="js/jquery.gritter.min.js"></script>
	
		<script src="js/jquery.imagesloaded.js"></script>
	
		<script src="js/jquery.masonry.min.js"></script>
	
		<script src="js/jquery.knob.modified.js"></script>
	
		<script src="js/jquery.sparkline.min.js"></script>
	
		<script src="js/counter.js"></script>
	
		<script src="js/retina.js"></script>

		<script src="js/custom.js"></script>
	<!-- end: JavaScript-->
	
</body>
</html>