<?php require_once('includes/initialize.php');  ?>

<?php

if($session->is_logged_in()) {
    if(isset($_GET['sem_id']))   {


      $semester = new Semester;
      $semester->Semester_ID = trim($_GET['sem_id']);
      if($semester->delete()){
          redirect_to('index.php');
      }

    }

}




?>