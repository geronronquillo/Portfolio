var albumID;

$(document).ready(function () {
    albumID = getParameter("id");
    
});



function uploadPhotos(id){
    var files=document.getElementById("image-selector").files;
    
    var index = 0;
    while (index!=files.length) {
        var tmppath = URL.createObjectURL(files[index]);
        var isCover = 0;
        var fileName = files[index].name;
        var isLast = false;
        if (index==0) {
            isCover = 1;
        }
        if (index == (files.length)-1) {
            isLast = true;
        }
        index++;
        savePhoto(tmppath, fileName, isCover, isLast);
    }
}
function savePhoto(url, fileName, isAlbumCover, isLast) {
    var img = new Image();

    img.onload = function () {
        var canvas = document.createElement("canvas");
        canvas.width =this.width;
        canvas.height =this.height;
        var ctx = canvas.getContext("2d");
        ctx.drawImage(this, 0, 0);

        var dataURL = canvas.toDataURL("image/png");
        alert(dataURL.length);
        if (dataURL.length > 3000000) {
            alert("The photo you are uploading is too large!");
        }else{
            $.ajax({
                url: 'includes/galleryConnections.php',
                type: 'post',
                data: {'action': 'addPhoto', 'fileName': fileName, 'isCover': isAlbumCover, 'data' : dataURL, 'date' : 'date', 'albumID' : albumID },
                success: function(data) {
                    if (isLast == true) {
                        if (data=='success') {
                            alert("You have successfully uploaded your photos!");
                            window.location = "photoGallery.php?id="+albumID;
                        }else{
                            alert("Failed to upload photos!");
                            window.location = "photoGallery.php?id="+albumID;
                        }
                        
                    }
                }, error: function(xhr, desc, err) {
                    alert("Failed to upload photos!");
                    window.location = "photoGallery.php?id="+albumID;
                }
            });    
        }
    };

    img.src = url;
}

function getParameter(variable) {
  var query = window.location.search.substring(1);
  var vars = query.split("&");
  for (var i=0;i<vars.length;i++) {
    var pair = vars[i].split("=");
    if (pair[0] == variable) {
      return pair[1];
    }
  } 
  alert('Query Variable ' + variable + ' not found');
}