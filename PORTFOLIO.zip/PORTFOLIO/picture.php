<?php require_once('includes/initialize.php');  ?>

<?php 

$album_id = $_GET['album_id'];

$message = "";
$message = $session->message;
?>

<?php include("includes/header.php"); ?>




			<!-- start: Content -->
			<div id="content" class="span10">
			
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.php">Home</a> 
					<i class="icon-angle-right"></i>
					Photos
				</li>
				
			</ul>

  			
  			<?php 
                if($message > " "){
            ?>
            <div class="alert alert-green">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong> 
                <?php 
                        echo $message;

                ?>
            </div>
            <?php } ?>
		


			<?php 
			$album = Album::find_by_id($album_id);

			?>

			<div class="row-fluid">	
				<div class="box green span12">
					<div class="box-header">
						<h2><i class="halflings-icon th-list"></i><span class="break"></span><?php echo $album->Album_name;?></h2>
						<h2 style="margin-left:500px;">Date created : <?php echo datetime_to_text($album->Date_added);?></h2>
					</div>
					<div class="box-content">
						
						<div class="masonry-gallery">
														<div id="image-1" class="masonry-thumb">
							<button data-toggle="modal" data-target="#<?php echo $_GET['album_id'];?>add_pic"><img style="hieght:150px; width:150px;" class="grayscale" src="img/gallery/add.png" alt="Sample Image 1"></button>
							</div>


							<?php 
							$photos = Photo::get_by_album_id($album_id);
							
						
							foreach ($photos as $photo) {
							?>

							<div id="image-2" class="masonry-thumb">
								<a title="<?php echo $photo->File_name;?>"  href="<?php echo 'photos/'.$photo->File_name;?>"><img class="grayscale" src="<?php echo 'photos/'.$photo->File_name;?>" alt="Image"></a>
								<span data-toggle="modal" href="#<?php echo $photo->Photo_ID;?>delete_photo"  style="height:10px; width:30px; margin-right: 200px" class="btn notification red"><h6 style="margin-top: 0px; margin-left: 0px; margin-right: 0px">delete</h6></span>
							</div>

							<?php } ?>
						

						 </div>



					</div>	
				</div><!--/span-->
				
			</div><!--/row-->








			</div>
			<!-- end: Content -->
		</div>
	</div><!--/fluid-row-->
	
		
	<div class="modal hide fade" id="myModal">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3>Settings</h3>
		</div>
		<div class="modal-body">
			<p>Here settings can be configured...</p>
		</div>
		<div class="modal-footer">
			<a href="#" class="btn" data-dismiss="modal">Close</a>
			<a href="#" class="btn btn-primary">Save changes</a>
		</div>
	</div>
	
	<div class="clearfix"></div>
    <footer id="footer" class="navbar navbar-default">
       <?php include("includes/footer.php"); ?>	
    </footer>

	
	<!-- start: JavaScript-->

		<script src="js/jquery-1.9.1.min.js"></script>
	<script src="js/jquery-migrate-1.0.0.min.js"></script>
	
		<script src="js/jquery-ui-1.10.0.custom.min.js"></script>
	
		<script src="js/jquery.ui.touch-punch.js"></script>
	
		<script src="js/modernizr.js"></script>
	
		<script src="js/bootstrap.min.js"></script>
	
		<script src="js/jquery.cookie.js"></script>
	
		<script src='js/fullcalendar.min.js'></script>
	
		<script src='js/jquery.dataTables.min.js'></script>

		<script src="js/excanvas.js"></script>
	<script src="js/jquery.flot.js"></script>
	<script src="js/jquery.flot.pie.js"></script>
	<script src="js/jquery.flot.stack.js"></script>
	<script src="js/jquery.flot.resize.min.js"></script>
	
		<script src="js/jquery.chosen.min.js"></script>
	
		<script src="js/jquery.uniform.min.js"></script>
		
		<script src="js/jquery.cleditor.min.js"></script>
	
		<script src="js/jquery.noty.js"></script>
	
		<script src="js/jquery.elfinder.min.js"></script>
	
		<script src="js/jquery.raty.min.js"></script>
	
		<script src="js/jquery.iphone.toggle.js"></script>
	
		<script src="js/jquery.uploadify-3.1.min.js"></script>
	
		<script src="js/jquery.gritter.min.js"></script>
	
		<script src="js/jquery.imagesloaded.js"></script>
	
		<script src="js/jquery.masonry.min.js"></script>
	
		<script src="js/jquery.knob.modified.js"></script>
	
		<script src="js/jquery.sparkline.min.js"></script>
	
		<script src="js/counter.js"></script>
	
		<script src="js/retina.js"></script>

		<script src="js/custom.js"></script>
	<!-- end: JavaScript-->
	
</body>
</html>