
<?php require_once('includes/initialize.php');  ?>

<?php

if($session->is_logged_in()) {
  redirect_to("index.php");
}

if(isset($_POST['submit'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $found_profile = Profile::authenticate($username, $password);


    
    if( $found_profile) {
      $session->login($found_profile); 
      redirect_to("index.php");
    } else {
      $message = "Username/Password combination incorrect.";
    }

     // echo "<h1>adwwdwdwWWW</h1>AAAAA {$username} AAAAA {$password} AAAAAAAAAAAAAAA-{$found_profile->username}-;AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA<h1>adwwdwdwWWW</h1></br></br></br></br></br>";

     // print_r($found_profile->Profile_id );


  } elseif (isset($_POST['reg'])) {
      $add_profile = new Profile;

      $username = trim($_POST['Username']);
      $password = trim($_POST['Password']);
      
      $fname = trim($_POST['Fname']);
      $mname = trim($_POST['Mname']);
      $lname = trim($_POST['Lname']);
      
      $gender = trim($_POST['Gender']);
      $birthdate = birthdate_to_datetime(trim($_POST['Birthdate']));
      $email = trim($_POST['Email']);
      $address = trim($_POST['Address']);
      $contact = trim($_POST['Contact']);
      $about_me = trim($_POST['about_me']);


      $add_profile->Username = $username;
      $add_profile->Password = $password;

      $add_profile->First_name = $fname;
      $add_profile->Middle_name = $mname;
      $add_profile->Last_name = $lname;

      $add_profile->Gender = $gender;
      $add_profile->Birthdate = $birthdate;
      $add_profile->Email_address = $email;
      $add_profile->Address = $address;
      $add_profile->Contact_number = $contact;
      $add_profile->About_me = $about_me;


      if($add_profile->save()){
          $message = "New account successfully created.";
      } else {
        $message = "Failed to create the new account.";
      }


  } else {
    $username = "";
    $password = "";
    $message  = "";
}
 
 if(isset($_POST['search_friend'])){

 }

?>

<!DOCTYPE html>
<html lang="en">
  
<!-- Mirrored from getbootstrap.com/2.3.2/examples/hero.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 13 Dec 2014 01:37:52 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <title>Portfolio</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Le styles -->
    <link href="css/bootstrap.css" rel="stylesheet">
    
    <link href="css/bootstrap-responsive.css" rel="stylesheet">
    <link id="base-style" href="css/style.css" rel="stylesheet">
    <link id="base-style-responsive" href="css/style-responsive.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&subset=latin,cyrillic-ext,latin-ext' rel='stylesheet' type='text/css'>

    <!-- HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]
      <script src="js/html5shiv.js"></script>
    <![endif]-->

    <!-- Fav and touch icons -->
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="ico/apple-touch-icon-114-precomposed.png">
      <link rel="apple-touch-icon-precomposed" sizes="72x72" href="ico/apple-touch-icon-72-precomposed.png">
                    <link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.png">
                                   <link rel="shortcut icon" href="ico/favicon.png">
  </head>
<br><br> <br><br> 

    <body style="background-color: #c963f3; background-repeat: no-repeat;">

    <div class="navbar navbar-inverse navbar-fixed-top">
      <div class="navbar-inner">
        <div class="container">
          <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="brand" href="#">My Portfolio</a>
          <div class="nav-collapse collapse">
           


            <form class="navbar-form pull-right" action="login.php" method="POST">
              <input class="span2" name="username" placeholder="Username" type="text" value="<?php echo $username; ?>" autofocus required>
              <input class="span2" name="password" placeholder="Password" type="password" required>
              <button type="submit" name="submit" class="btn" style="height:30px; width:80px; margin-top:-5px;">Sign-in</button>
            </form>


            <div class="navbar-form pull-right" style="margin-right:2%; margin-top:1%;">
                <?php echo $message;?>
            </div>
          </div><!--/.nav-collapse -->
        </div>
      </div>
    </div>
<div class="container">
<div class="hero-unit"  style="background-image: url('img/nature.png'); background-size: 600px 650px; background-repeat: repeat;">


    <!-- Main hero unit for a primary marketing message or call to action -->
    <h1>WELCOME!</h1>

    <p>This site is for a simple event recording or a personal portfolio for an informational 
      website in your future use. It includes a large saving file and a Gallery purposes. Use it as a starting point to create 
      something more unique.Be thrilled and excited on the great personal activities that you’re about to encounter! Gear up and be ready to explore!
    </p>
                                <br><br> <br> <br><hr>
    <h6 class="pull-right" style="color:white"> If you haven't yet signed-up. <br>click here below! </h6><br><br>
    <p><a type="submit" class="btn btn-primary btn-large pull-right" data-toggle="modal" data-target="#create_pro">Sign-up »</a></p> 
          
   
</div>
</div>

<!-- /.start modal sa action--> 


<div class="modal hide fade" id="create_pro">
    <div class="modal-dialog">
        <div class="modal-content" style="background-color: #c963f3;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h1 class="modal-title" id="myModalLabel">Fill-up Registration Form</h1>
            </div>
      <div class="modal-body">
  
        <form action="login.php" method="POST">  
          
          <div class="input-prepend success" title="user">
            <input class="input-large span5" name="Username" id="username" type="text" required="" placeholder="Username"/>
          </div>
          <div class="input-prepend success" title="password">
            <input class="input-large span5" name="Password" id="password" type="password" required="" placeholder="Password "/>
          </div>
          <hr>



          <div class="input-prepend success" title="Fname">
            <input class="input-large span5" name="Fname" id="Fname" type="text" required="" placeholder="First Name "/>
          </div>

          <div class="input-prepend success" title="Mname">
            <input class="input-large span5" name="Mname" id="Mname" type="text" required="" placeholder="Middle Name "/>
          </div>

          <div class="input-prepend success" title="Lname">
            <input class="input-large span5" name="Lname" id="Lname" type="text" required="" placeholder="Last Name "/>
          </div>

          <div class="control-group">
            <label class="control-label" for="Gender">Gender</label>
            <div class="controls">
              <select id="Gender" data-rel="chosen" name="Gender">
                <option value="male">Male</option>
                <option value="female">Female</option>
              </select>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label">Birth Date</label>
            <div class="controls">
              <input type="text" class="input-xlarge datepicker" name="Birthdate" id="date01" value="02/16/12">
            </div>
          </div>

          <div class="input-prepend success" >
            <input class="input-large span5" name="Email" type="email"  placeholder="Email Address"/>
          </div>

          <div class="input-prepend success" title="Address">
            <input class="input-large span5" name="Address" id="Address" type="text" placeholder="Address "/>
          </div>

          <div class="input-prepend success" title="Address">
            <input class="input-large span5" name="Contact" id="contact" type="text" placeholder="Contact "/>
          </div>

          <div class="control-group hidden-phone">
            <label class="control-label" for="textarea2">About Me</label>
            <div class="controls">
            <textarea   class="input-large span5" name="about_me" id="textarea2" rows="3" maxlength="300"></textarea>
            </div>
          </div>


          <hr>

            <a class="btn btn-danger" data-dismiss="modal" style="width:240px">Cancel</a>
            <button class="btn btn-success" type="submit" name="reg" style="width:240px">Submit Registration Form</button>
        
        </form>                                        
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal --> 











      
    </div> <!-- /container -->
<!-- start: JavaScript-->

    <script src="js/jquery-1.9.1.min.js"></script>
  <script src="js/jquery-migrate-1.0.0.min.js"></script>
  
    <script src="js/jquery-ui-1.10.0.custom.min.js"></script>
  
    <script src="js/jquery.ui.touch-punch.js"></script>
  
    <script src="js/modernizr.js"></script>
  
    <script src="js/bootstrap.min.js"></script>
  
    <script src="js/jquery.cookie.js"></script>
  
    <script src='js/fullcalendar.min.js'></script>
  
    <script src='js/jquery.dataTables.min.js'></script>

    <script src="js/excanvas.js"></script>
  <script src="js/jquery.flot.js"></script>
  <script src="js/jquery.flot.pie.js"></script>
  <script src="js/jquery.flot.stack.js"></script>
  <script src="js/jquery.flot.resize.min.js"></script>
  
    <script src="js/jquery.chosen.min.js"></script>
  
    <script src="js/jquery.uniform.min.js"></script>
    
    <script src="js/jquery.cleditor.min.js"></script>
  
    <script src="js/jquery.noty.js"></script>
  
    <script src="js/jquery.elfinder.min.js"></script>
  
    <script src="js/jquery.raty.min.js"></script>
  
    <script src="js/jquery.iphone.toggle.js"></script>
  
    <script src="js/jquery.uploadify-3.1.min.js"></script>
  
    <script src="js/jquery.gritter.min.js"></script>
  
    <script src="js/jquery.imagesloaded.js"></script>
  
    <script src="js/jquery.masonry.min.js"></script>
  
    <script src="js/jquery.knob.modified.js"></script>
  
    <script src="js/jquery.sparkline.min.js"></script>
  
    <script src="js/counter.js"></script>
  
    <script src="js/retina.js"></script>

    <script src="js/custom.js"></script>
  <!-- end: JavaScript-->
  
</body>
</html>