
<?php include("includes/initialize.php"); ?>

<?php 

if(isset($_POST['add_subject'])){
	$add_subject 					= new Subject();
 	
 	$add_subject->Subject_ID 		= trim($_POST['Subject_ID']);
	$add_subject->Subject_name  	= trim($_POST['Subject_name']);
	$add_subject->Description  		= trim($_POST['Description']);
	$add_subject->Unit  			= trim($_POST['Unit']);
	$add_subject->Grade  			= trim($_POST['Grade']);
	$add_subject->Semester_ID		= trim($_POST['Semester_ID']);
	if($add_subject->Grade == "INC"){
		$add_subject->Complete_grade = trim($_POST['Grade_com']);
	}
	if($add_subject->Grade != "INC" && !empty($add_subject->Complete_grade)){
		$add_subject->Complete_grade = NULL;
	}
	$add_subject->Profile_ID		= trim($profile->Profile_ID);
	// $add_subject->Instructor_name  	= trim($_POST['Instructor_name']);
	// $add_subject->Section  			= trim($_POST['Section']);
	// $add_subject->Room  			= trim($_POST['Room']);

	if($add_subject->update_subject()){
		$subject = Subject::get_all_subjects();
	}
}

include("includes/header.php");

?>
			<!-- start: Content -->
			<div id="content" class="span10">
			
			
			<ul class="breadcrumb">
				<li>
					<i class="icon-home"></i>
					<a href="index.php">Home</a> 
					<i class="icon-angle-right"></i>
				</li>
				<li><a href="#">Tables</a></li>
			</ul>

			<div class="row-fluid sortable">		
				<div class="box span12">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon edit"></i><span class="break"></span>My Personal Grade Evaluation </h2>
						
					</div>
					<div class="box-content">
						<table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Subject</th>
								  <th>Description</th>
								  <th>Units</th>
								  <th>Grade</th>
								  <th>Grade Completion</th>
								  <th></th>
							  </tr>
						  </thead>   
						  <tbody>
							
						  <?php 

							$subject = Subject::get_all_subjects();
							while($subj = array_shift($subject)){

						  ?>


							<tr>
								<td style="font-size:15px"><?php echo $subj->Subject_name; ?></td>
								<td><?php echo $subj->Description; ?></td>
								<td class="center"><?php echo $subj->Unit; ?></td>
								<td class="center" 
								<?php 
								if($subj->Grade == '5.0' || $subj->Grade == 'INC' || $subj->Grade == 'DRP' || $subj->Grade == 'ODP'){
									echo "style='color:red;'";
								}
								echo '>'.$subj->Grade; 
								?></td>
								<td class="center"><?php if($subj->Grade == 'INC'){ echo $subj->Complete_grade;} ?></td>
								<td class="center">
									<a class="btn btn-info" data-toggle="modal" href="#<?php echo $subj->Subject_ID; ?>">
										<i class="halflings-icon white edit"></i>  
									</a>
									<a class="btn btn-danger" data-toggle="modal" data-target="#delete_grade<?php echo $subj->Subject_ID?>">
										<i class="halflings-icon white trash"></i>  
									</a>
								</td>
							</tr>
							

							<?php } ?>

						  </tbody>
					  </table>            

					</div>
				</div><!--/span-->
			
			</div><!--/row-->
	</div><!--/.fluid-container-->
	
			<!-- end: Content -->
		</div><!--/#content.span10-->
		</div><!--/fluid-row-->
	
		
	<div class="modal hide fade" id="myModal">
		<div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">×</button>
			<h3>Settings</h3>
		</div>
		<div class="modal-body">
			<p>Here settings can be configured...</p>
		</div>
		<div class="modal-footer">
			<a href="#" class="btn" data-dismiss="modal">Close</a>
			<a href="#" class="btn btn-primary">Save changes</a>
		</div>
	</div>
	
	<div class="clearfix"></div>
	
	<footer id="footer" class="navbar navbar-default">
       <?php include("includes/footer.php"); ?>     
    </footer>
	
	<!-- start: JavaScript-->

		<script src="js/jquery-1.9.1.min.js"></script>
	<script src="js/jquery-migrate-1.0.0.min.js"></script>
	
		<script src="js/jquery-ui-1.10.0.custom.min.js"></script>
	
		<script src="js/jquery.ui.touch-punch.js"></script>
	
		<script src="js/modernizr.js"></script>
	
		<script src="js/bootstrap.min.js"></script>
	
		<script src="js/jquery.cookie.js"></script>
	
		<script src='js/fullcalendar.min.js'></script>
	
		<script src='js/jquery.dataTables.min.js'></script>

		<script src="js/excanvas.js"></script>
	<script src="js/jquery.flot.js"></script>
	<script src="js/jquery.flot.pie.js"></script>
	<script src="js/jquery.flot.stack.js"></script>
	<script src="js/jquery.flot.resize.min.js"></script>
	
		<script src="js/jquery.chosen.min.js"></script>
	
		<script src="js/jquery.uniform.min.js"></script>
		
		<script src="js/jquery.cleditor.min.js"></script>
	
		<script src="js/jquery.noty.js"></script>
	
		<script src="js/jquery.elfinder.min.js"></script>
	
		<script src="js/jquery.raty.min.js"></script>
	
		<script src="js/jquery.iphone.toggle.js"></script>
	
		<script src="js/jquery.uploadify-3.1.min.js"></script>
	
		<script src="js/jquery.gritter.min.js"></script>
	
		<script src="js/jquery.imagesloaded.js"></script>
	
		<script src="js/jquery.masonry.min.js"></script>
	
		<script src="js/jquery.knob.modified.js"></script>
	
		<script src="js/jquery.sparkline.min.js"></script>
	
		<script src="js/counter.js"></script>
	
		<script src="js/retina.js"></script>

		<script src="js/custom.js"></script>
	<!-- end: JavaScript-->
	
</body>
</html>