<?php require_once('includes/initialize.php');  ?>

<?php

if($session->is_logged_in()) {
    if(isset($_GET['Subject_ID']))   {


      $subject = new Subject;
      $subject->Subject_ID = trim($_GET['Subject_ID']);
      if($subject->delete()){
          redirect_to('evaluation.php');
      }

    }

}




?>