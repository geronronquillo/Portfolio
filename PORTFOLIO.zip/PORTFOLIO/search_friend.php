
<?php require_once('includes/initialize.php');  ?>

<?php include("includes/header.php"); ?>


    <div class="modal-dialog">
        <div class="modal-content" style="background-color:orange;">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h2 class="modal-title" id="myModalLabel">Hi i am Geron Ronquiilo </h2>
            </div>
            <div class="modal-body">
        <fieldset>
        <div class="well bs-component" style="background-color:black">
            <div class="bs-component">
              <ul class="nav nav-tabs">
                <li class="active"><a href="#INFO" data-toggle="tab">About me</a></li>
                <li><a href="#EVALUATION" data-toggle="tab">Evaluation</a></li>
              </ul>
              <div id="myTabContent" class="tab-content">
                <div class="tab-pane fade active in" id="INFO">
                  <p>
                    <h2>
                    Picture:
            <hr />
            Name:  <hr /> 
            Birthdate: <hr />
            Gender:<hr />
            Address:<hr />
            Contact Number: <hr />
            About Me: <hr />

            </h2>
                  </p>
                </div>
                 
                 <div class="tab-pane fade" id="EVALUATION">
                  <p>
                   
      <div class="row-fluid sortable">
        <div class="box span6">
          <div class="box-header">
            <h2><i class="halflings-icon align-justify"></i><span class="break"></span>Simple Table</h2>
          </div>
          <div class="box-content">
            <table class="table">
                <thead>
                  <tr>
                    <th>Username</th>
                    <th>Date registered</th>
                    <th>Role</th>
                    <th>Status</th>                                          
                  </tr>
                </thead>   
                <tbody>
                <tr>
                  <td>Dennis Ji</td>
                  <td class="center">2012/01/01</td>
                  <td class="center">Member</td>
                  <td class="center">
                    <span class="label label-success">Active</span>
                  </td>                                       
                </tr>
                                                   
                </tbody>
             </table>  
                 
          </div>
        </div><!--/span-->
        
        <div class="box span6">
          <div class="box-header">
            <h2><i class="halflings-icon align-justify"></i><span class="break"></span>Striped Table</h2>
          </div>
          <div class="box-content">
            <table class="table table-striped">
                <thead>
                  <tr>
                    <th>Username</th>
                    <th>Date registered</th>
                    <th>Role</th>
                    <th>Status</th>                                          
                  </tr>
                </thead>   
                <tbody>
                <tr>
                  <td>Dennis Ji</td>
                  <td class="center">2012/01/01</td>
                  <td class="center">Member</td>
                  <td class="center">
                    <span class="label label-success">Active</span>
                  </td>                                       
                </tr>
                                                   
                </tbody>
             </table>  
             
          </div>
        </div><!--/span-->
      </div><!--/row-->
                  </p>
                </div>
                
                
              </div>

          </div>
          </div>
        </fieldset>
                                               
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->

<!-- /.modal --> 



